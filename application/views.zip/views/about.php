 
<!-- About Us -->
    <section class="about-us" style="background-image: url(Assets/images/background/about.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    /*opacity: .80;*/
    /*transform: scaleX(-1);">
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Content Column -->
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title text-center" data-aos="zoom-in" style="margin-bottom: 8px;">
                        <h2 style="color: #f98e08;">About Us</h2>
                      
                    </div>
                        
                        <div class="text-box" data-aos="fade-right">
                            <p> Umiko Products is one of the most reputed manufacture and supplier of industrial product include like Floor Cleaner, Toilet Cleaner, Dish Wash,  liquid soft soap. 
                              We use high quality raw materials to produce these chemicals to ensure that only high standard products are manufactured.  

                         
 </p>
                        </div>
                       
                        
                    </div>
                </div>

               
            </div>

            <div class="container about_product py-1">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12 " data-aos="fade-right">
                        <h4>Our Products</h4>
                        <li>Dish Wash</li>
                         <li>Floor Cleaner</li>
                         
                          <li>Soft Soap</li>
                            <li>Toilate Cleaner</li>
                            
                    </div>

                
                </div>
            </div>
        </div>
    </section>
    <!-- End About Us -->

   

   

    
    
