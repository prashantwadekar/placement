




<!-- Contact Section -->
    <section class="contact-section" id="contact">
        <div class="auto-container">
       
          
            <div class="row clearfix">
                <!-- Form Column -->
                <div class="form-column col-lg-6 col-md-12 col-sm-12 order-2" data-aos="fade-left">
                    <div class="inner-column">
                        <div class="contact-form">
                               <form role="form" id="Form" action="" method="post">
                                <div class="response"></div>

                                <div class="form-group">
                                    <input type="text" id="userName" name="userName" class="username" placeholder="Name" *autofocus="autofocus" onkeypress="return onlyAlphabets(event,this)"  value="" data-parsley-trigger="change"  required>
                                    
                                    <!-- Update code -->
                                    <input type="hidden" class="form-control form-control-sm" id="userId" name="userId"  value="" data-parsley-trigger="change"  required>
                                </div>
                            
                            <!-- Mobile No -->
                                  <div class="form-group">
                                    <input type="text" id="MobileNo" name="MobileNo" class="username" placeholder="Mobile no" *autofocus="autofocus" onkeypress="return isNumberKey(event,this)"  value="" data-parsley-trigger="change" maxlength="10"  required>
                                </div>

                              
                            <!-- Email -->
                                <div class="form-group">
                                    <input type="email" name="email" id="email" class="email" placeholder="Email"*autofocus="autofocus" value="" data-parsley-trigger="change"  required>
                                </div>
                                
                                <div class="form-group">
                                    <textarea name="Requirment" id="Requirment" class="message" placeholder="Requirment"*autofocus="autofocus" value="" data-parsley-trigger="change"  required></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <button class="theme-btn btn-style-two"  type="button" name="btn_save" id="btn_save"><span class="btn-title">Submit Now</span> <span></span><span></span><span></span><span></span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Contact Column -->
                <div class="contact-column col-lg-6 col-md-12 col-sm-12 p-2">
                    <div class="inner-column">
                        <div class="row no-gutters">
                            <div class="contact-info-block col-lg-6 col-md-6 col-sm-12 pb-3" data-aos="zoom-in">
                                <div class="inner">
                                     <span class="icon flaticon-worldwide"style="    color: #1226b5;"></span>  
                                    <h4>Address</h4>
                            <p> Jatrat Ves,Nipani,Belagavi<br>Karnataka,591237,INDIA.</p>
                                </div>
                            </div>

                            <div class="contact-info-block col-lg-6 col-md-6 col-sm-12 p-2 pb-3"data-aos="zoom-in">
                                <div class="inner">
                                    <span class="icon flaticon-phone"style="color: #00a65a;"></span> 
                                    <h4>Call Us</h4>
                                    <p><a href="tel:+91 7483028077" style="text-decoration: none;">+91 7483028077</a></p>
                                    <p><a href="tel:9845253653" style="text-decoration: none;">+91 9845253653</a></p>
                                </div>
                            </div>

                            <div class="contact-info-block col-lg-6 col-md-6 col-sm-12 p-2 pb-3"data-aos="zoom-in">
                                <div class="inner">
                                   <span class="icon flaticon-email" style="    color: #f39c12;"></span>  
                                    <h4>Mail Us</h4>
                                    <p><a href="mailto:customerumiko@gmail.com" style="text-decoration:none;">customerumiko@<br>gmail.com</a></p>
                                    
                                    
                                </div>
                            </div>

                            <div class="contact-info-block col-lg-6 col-md-6 col-sm-12 p-2"data-aos="zoom-in">
                                <div class="inner">
                                   <span class="icon flaticon-clock" style="color: #d9250f;"></span>  
                                    <h4> Work Time</h4>
                                    <p>Mon - Sat: 09AM to 05PM</p>
                                    <p>Sunday - Close</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Section -->

    <!-- Map Section -->
    <section class="map-section">
        <div class="map-outer">
          
             <div id="map" class="map-canvas" >

                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15309.624630166389!2d74.3787021!3d16.4041861!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa0327ecd3022f8a4!2sUMIKO!5e0!3m2!1sen!2sin!4v1649135313013!5m2!1sen!2sin" style="width: 100%;" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> </div>
           <!--      <script>
                    function initMap() 
                   { 
             var Karnataka  = { lat:16.41124, lng:74.38534};

        var map = new google.maps.Map(document.getElementById("map"), 
            {
             zoom: 10,
              center: Karnataka,
            }
            );

            const marker = new google.maps.Marker({
              position:Karnataka,
              map: map,
              });
                }
                </script>
                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpfS1oRGreGSBU5HHjMmQ3o5NLw7VdJ6I&amp;callback=initMap">
                </script> -->
           

        </div>
    </section>
    <!-- End Map Section -->

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>           
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Contact_Create.js"></script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/common/common_validations.js"></script>