
<style type="text/css">
.slider_wrap{
    /*background-image: linear-gradient( 
339deg, rgb(27 163 233)50%, rgba(255,255,255,0.9)50%);*/

}
  /*.gallery_slider{
     border: 2px solid var(--common_color);
    border-radius: 5px!important;
  }*/
  .gallery_slider .bg{
    background-image: url(Assets/images/gallery/bg2.jpg);
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    height: 338px;
  }
  .slick-slide img{
    height: 200px!important;
    width: 185px!important;
    margin: 9% auto 0 auto!important;

  }
  @media(max-width: 767px){
    .gallery_slider .bg{
    
      height: 200px;
  }
    .slick-slide img{
    height: 173px!important;
    width: 135px!important;
    margin: 0% auto 0 auto!important;

  }
  }
  .thumbnail_slider_area .thumbnail_gallery_slider img {
    border: 2px solid var(--common_color);
    border-radius: 3px 10px 3px 10px!important;
    height: 150px!important;
    width: 85%!important;

}
@media(max-width: 600px){
  .thumbnail_slider_area .thumbnail_gallery_slider img {
    border: 2px solid var(--common_color);
    border-radius: 3px 10px 3px 10px!important;
    height: 100px!important;
    width: 100%!important;
}  
}
</style>
<!--Our Gallery start-->
    <section class="gallery-section">
        <!--  <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-title text-center"data-aos="fade-right">
                        <h2>Our Gallery</h2>
                       
                    </div>
                </div>
               
            </div> -->
        </section>


        <section id="slick">
    <div class="">
        <div class="row">
            <div class="col-lg-12">
                <div class="slider_wrap">
                    <div class="gallery_slider text-center">
                        <div class="bg">
                        <img src="<?=base_url("Assets/images/Product/Product10.png") ?>"  ></div>
                          
                        <div class="bg">
                        <img src="<?=base_url("Assets/images/Product/Product3.png") ?>"  ></div>
                    
                        <div class="bg">
                        <img src="<?=base_url("Assets/images/Product/Product6.png") ?>"  ></div>

                    
                      <div class="bg">
                        <img src="<?=base_url("Assets/images/Product/Product5.png") ?>"  ></div>

                     <div class="bg">
                    <img src="<?=base_url("Assets/images/Product/Product3.png") ?>"  ></div>
                    
                      <div class="bg">
                        <img src="<?=base_url("Assets/images/Product/Product6.png") ?>"  ></div>

                        

                </div>
                <div class="arrow_prev">
                    <span><i class="fas fa-chevron-left fa-1x text-info"></i></span>
                </div>
                <div class="arrow_next">
                    <span><i class="fas fa-chevron-right fa-1x text-info"></i></span>
                </div>
            </div>
        </div>
    </div>
 </section>

    
<div class="row thumbnail_slider_area">
    <div class="container">

        <div class="row no-gutters  thumbnail_gallery_slider">
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product10.png") ?>" alt="" >
            </div>
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product3.png") ?>" alt="" >
            </div>
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product6.png") ?>" alt="" >
            </div>
           
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product5.png") ?>" alt="" >
            </div>
            
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product3.png") ?>" alt="" >
            </div>
            <div class="p-2">
                <img src="<?=base_url("Assets/images/Product/Product6.png") ?>" alt="" >
            </div>
        </div>
    </div>
</div>
<script src="<?=base_url("Assets/js/jquery.js") ?>"></script> 

<script src="<?=base_url("Assets/js/slick.js") ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
      $('.gallery_slider').slick({
        prevArrow:'.arrow_prev',
         nextArrow:'.arrow_next',
         dots:false,
          autoplay:true,
         // autoplaySpeed:3000,
         slidesToShow: 1,
         slidesToScroll: 1,
         arrows: true,
         fade: true,
         asNavFor: '.thumbnail_gallery_slider'
});
  
  $('.thumbnail_gallery_slider').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  asNavFor: '.gallery_slider',
  dots: false,
  arrows: false,
  // centerMode: true,

  focusOnSelect: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
  });
</script>
    <!-- Our Gallery End

