<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">
<title>Umiko</title>

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="">
<meta name="description" content="Umiko">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<meta name="keywords" content="TOILET CLEANER,SOFT SOAP,DISH WASH,FLOOR CLEANER,best TOILET CLEANER,best SOFT SOAP,best DISH WASH,best FLOOR CLEANER,Email:customerumiko@gmail.com,Mobile No:
+91 7483028077,Address:Nipani,umiko Nipani,Belagavi,Karnataka,umikoo Karnataka ">

<!-- Stylesheets -->
<link href="<?=base_url("Assets/css/bootstrap.css") ?>" rel="stylesheet">
<link href="<?=base_url("Assets/css/style.css") ?>" rel="stylesheet">
<link href="<?=base_url("Assets/css/responsive.css") ?>" rel="stylesheet">
<link href="<?=base_url("Assets/css/slick.css") ?>" rel="stylesheet">

<!--Color Themes-->
<link id="theme-color-file" href="<?=base_url("Assets/css/color-themes/default-theme.css") ?>" rel="stylesheet">
<!-- Favicon -->
<link rel="shortcut icon" href="<?=base_url("Assets/images/favicon.png") ?>" type="image/x-icon">


<!-- Animate to Scroll -->
<link rel="stylesheet" href="<?=base_url("Assets/css/aos.css") ?>" />

  
  <!-- Custom CSS -->  
     
    
   <link rel="stylesheet" href="<?php echo base_url(); ?>web_resources/dist/css/sweetalert.css">
       
       
         <!-- Clock picker Css End -->
       
         <script>
        var base_path="<?php echo base_url();?>";
     </script>


  
</head>

<body>

<!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header p-3" style="border-bottom: 3px solid #3596ff!important;display: flex;
    justify-content: center;border-radius: 26px;">

          <h3 class="modal-title" style="font-family: 'Lora';
        color: var(--common_color);font-weight: 800;">Enquery Now</h3>
          <button type="button" class="close" data-dismiss="modal"><i class="fas fa-times fa-1x" style="    color: var(--common_color);opacity: 1.1!important;"></i></button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <form action="" method="post" id="Form">
    <div class="form-group">
      <label for="usr">Name:</label>
      <input type="text" class="form-control" id="person" name="personname">
    </div>
    <div class="form-group">
      <label for="pwd">Mobile No:</label>
      <input type="text" class="form-control" id="mob" name="mobile" maxlength="10">
    </div>

     <div class="form-group">
      <label for="msg">Message:</label>
       <textarea type="text" class="form-control" rows="5" id="msg" name="msg1"></textarea>
  
    </div>
    <button type="button" class="btn btn-primary" id="enquery">Enquery Now</button>
  </form>
        </div>
     
        
      </div>
    </div>
  </div>
  
</div>

  


<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
    
    <!-- Main Header-->
    <header class="main-header">
        <!--Header Top-->
        <div class="header-top">
            <div class="auto-container clearfix">
             
                <div class="top-left">
                    <ul class="contact-info clearfix">
                        <li><span class="icon fas fa-phone-volume" ></span> <a href="tel:+91 7483028077">+91 7483028077</a></li>

                        <li><span class="icon fab fa-whatsapp"></span> <a href="tel:9845253653">+91 9845253653</a></li>

                          <li><span class="icon fas fa-hand-point-right"></span><button data-toggle="modal" data-target="#myModal"  data-backdrop='static'>Enquery Now</button></li>
                          
                        <li style="cursor: pointer;"><span class="icon fas fa-envelope"></span> <a href="mailto:customerumiko@gmail.com">customerumiko@gmail.com</a></li>
                      
                    </ul>
                     <div class="top-right">
                   
               
                    <ul class=" social-icon-one clearfix">

                        <li><a href="#"style="background: #3b5998;"><i class="fab fa-facebook-f"></i></a></li>

                        <li><a href="#"style="background: #1DA1F2;"><i class="fab fa-twitter" ></i></a></li>
                        <li><a href="#"style="background: #4285F4;"><i class="fab fa-google-plus-g" ></i></a></li>
                        <li><a href="#"style="background: #FF0000;"><i class="fab fa-youtube" ></i></a></li>
                        <li><a href="#"style="background: #0072b1;"><i class="fab fa-linkedin-in" ></i></a></li>
                    </ul> </div> 
                </div>
            </div>
        </div>
        <!-- End Header Top -->

       <!--Header Lower-->
        <div class="header-lower">
            <div class="auto-container">
              
              
                <div class="main-box clearfix">
                    <div class="pull-left logo-outer">
                        <div class="logo"><a href="<?php echo base_url();?>home"><img src="<?=base_url("Assets/images/Ulogo.png") ?>" alt="" title=""></a></div>
                    </div>

                    <!--Nav Box-->
                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>

                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                
                                   <li><a href="<?php echo base_url();?>Home"><span class="fas fa-home" style="color: #1f60c0">&nbsp;&nbsp;</span>HOME</a>
                                      </li>
                                    
                                   <li><a href="<?php echo base_url();?>About"><span class="fas fa-user" style="color: #1f60c0">&nbsp;&nbsp;</span>ABOUT</a>
                                      </li>
                                     
                                     

                                    <li class="dropdown"><a href="<?php echo base_url();?>Product"><span class="fas fa-shopping-basket" style="color: #1f60c0">&nbsp;&nbsp;</span>PRODUCTS</a>
                                       
                                      </li>

                                      

                                      <li><a href="<?php echo base_url();?>Contact"><span class="fas fa-envelope" style="color: #1f60c0">&nbsp;&nbsp;</span>CONTACT US</a>
                                      </li>
                                      
                                      <li class="d-none d-md-block"><a href="<?php echo base_url();?>contact"><span class="" style="color: var(--blue)">&nbsp;&nbsp;</span></a>
                                       
                                      </li>

                                      <li class="d-none d-md-block"><a href="<?php echo base_url();?>contact"><span class="" style="color: var(--blue)">&nbsp;&nbsp;</span></a>
                                       
                                      </li>

                                       <li class="d-none d-md-block"><a href="<?php echo base_url();?>contact"><span class="" style="color: var(--blue)">&nbsp;&nbsp;</span></a>
                                       
                                      </li>

                                      
                                      
                                
                                    
                                </ul>
                            </div>
                        </nav>
                        <!-- Main Menu End-->

                        
                    </div>
                </div>
            </div>
        </div>
        <!--End Header Lower-->
        <!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="<?=base_url("Home")  ?>" title=""><img src="<?=base_url("Assets/images/Ulogo.png") ?>" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="nav-outer pull-right">
                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                    
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                             <ul class="navigation clearfix"><!--Keep This Empty / Menu will come through Javascript--></ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
            </div>
        </div><!-- End Sticky Menu -->


        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-cancel-1"></span></div>
            
            <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
            <nav class="menu-box">
                <div class="nav-logo"><a href="<?=base_url("Home")  ?>"><img src="<?=base_url("Assets/images/Ulogo.png") ?>" alt="" title=""></a></div>
                
                <ul class="navigation clearfix"><!--Keep This Empty / Menu will come through Javascript--></ul>
            </nav>
        </div><!-- End Mobile Menu -->
    </header>
    <!--End Main Header -->