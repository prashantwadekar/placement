


 <!-- Services Section -->
    <section class="services-section mt-0">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-title text-center"data-aos="zoom-in">
                        <h2>Our Products</h2>
                       
                    </div>
                </div>
               
            </div>


                 <div class="container  pb-2">
                    <div class="row">
                        <div class="col-12 col-md-4 mt-2">
                    <div class="card-wrapper one" >
  <div class="card-header">
   <!--  <i class="fas fa-chess-rook"></i> -->
    <img src="<?=base_url() ?>Assets/img/products/dish_washN.png" style="height:165px;width: 43%;">
     <h1 class="card-header-text2">Dish Wash</h1>
    <p class="card-header-text3">Take Umiko Dish Wash gel 5 ml (1 Teaspoon) into bowl of water (50 ml) dip the scrubber squire it to get powerful cleaning solution to clean your utensils with sparkling shine.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>  
    


      <!--  Second Row -->
      <div class="col-12 col-md-4 mt-2">
    <div class="card-wrapper two" >
  <div class="card-header">
   <img src="<?=base_url() ?>Assets/img/products/soft_soapN.png" style="height:165px;width: 43%;">
   
    <h1 class="card-header-text2">Soft Soap</h1>
    <p class="card-header-text3">Use soap & water,Rub hands,Dry with paper towel,Use towel to turn off faucet.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products/soft_soap") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>

<!--  Third Row -->
<div class="col-12 col-md-4 mt-2">
     <div class="card-wrapper three" >
  <div class="card-header">
    <img src="<?=base_url() ?>Assets/img/products/toiletN.png" style="height:165px;width: 37%;">
    <h1 class="card-header-text2">TOILET CLEANER</h1>
    <p class="card-header-text3">Flush, Remove container cap & direct nozzle under toilet rim, squire liquid around the sides,  Leave it for 4 to 5 minutes, Brush it gently  Flush once more for sparkling & fresh toilets.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products/product4") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>

</div>

  <div class="row">
    <div class="col-12 col-md-4 mt-2">
   <div class="card-wrapper one" >
  <div class="card-header">
    <img src="<?=base_url() ?>Assets/img/products/surfaceN.png" style="height:165px;width: 43%;">
    <h1 class="card-header-text2">SERFACE FLOOR CLEAN</h1>
    <p class="card-header-text3">Take 1 cap full Umiko Surface floor cleaner and add in to half of bucket for regular use.Apply directly on oily and heavy stained surface leave it for 10
minute and rinse with water.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products/product2") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div></div>  
    
  
  <div class="col-12 col-md-4 mt-2">
                    <div class="card-wrapper one" >
  <div class="card-header">
   <!--  <i class="fas fa-chess-rook"></i> -->
    <img src="<?=base_url() ?>Assets/img/products/dish_washN.png" style="height:165px;width: 43%;">
     <h1 class="card-header-text2">Dish Wash</h1>
    <p class="card-header-text3">Take Umiko Dish Wash gel 5 ml (1 Teaspoon) into bowl of water (50 ml) dip the scrubber squire it to get powerful cleaning solution to clean your utensils with sparkling shine.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>   


 <!--  Second Row -->
      <div class="col-12 col-md-4 mt-2">
    <div class="card-wrapper two" >
  <div class="card-header">
   <img src="<?=base_url() ?>Assets/img/products/soft_soapN.png" style="height:165px;width: 43%;">
   
    <h1 class="card-header-text2">Soft Soap</h1>
    <p class="card-header-text3">Use soap & water,Rub hands,Dry with paper towel,Use towel to turn off faucet. </p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>


</div>


 </div>

            
           
              
 </div>
    </section>
    <!-- End service Section -->