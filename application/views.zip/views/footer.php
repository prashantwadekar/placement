 <!-- Main Footer -->
    <footer class="main-footer" style="background-image: url(Assets/images/background/12.png);">
        <div class="auto-container">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row">
                    <!--Footer Column-->
                    <div class="footer-column col-xl-4 col-lg-5 col-md-12 col-sm-12">
                        <div class="footer-widget about-widget">
                            <div class="footer-logo">
                                <figure class="image"><img src="<?=base_url("Assets/images/logo-2.html") ?>" alt=""></a></figure>
                            </div>
                            <div class="widget-content">
                                <div class="text"> We use high quality raw materials to produce these chemicals to ensure that only high standard products are manufactured.  </div>
                                <ul class="contact-list">
                                    <li><span class="fas fa-home fa-3x"></span> Jatrat Ves,Nipani,Belagavi(Belgaum),<br>Karnataka,591237,INDIA.
</li>
                                    <li><span class="fas fa-envelope"></span> <a href="mailto:Supportyou@demo.com" class="text-white">customerumiko@gmail.com</a></li> 
                                    <li><span class="fas fa-phone-volume"></span><a href="tel:+91 9373421225" class="text-white">+91 7483028077</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!--Footer Column-->
                    <div class="footer-column col-xl-5 col-lg-7 col-md-12 col-sm-12">
                        <!--Footer Column-->
                        <div class="footer-widget links-widget">
                            <div class="row">
                                <div class="col-lg-7 col-md-6">
                                    <h2 class="widget-title">Products</h2>
                                     <!--Footer Column-->
                                    <div class="widget-content">
                                        <ul class="list-style-two">
                                            <li><a href="<?php echo base_url("Product"); ?>">   Dish Wash</a></li>

                                             <li><a href="<?php echo base_url("Product"); ?>">Soft Soap</a></li>

                                           

                                            <li><a href="<?php echo base_url("Product"); ?>">Surface Floor Cleaner</a></li>
                                            <li><a href="<?php echo base_url("Product"); ?>"> Toilet Cleaner</a></li>
                                            
                                           
                                            

                                           
                                        </ul>
                                    </div>
                                </div>

                                <div class="col-lg-5 col-md-6">
                                    <h3 class="widget-title">Useful Links</h3>
                                     <!--Footer Column-->
                                    <div class="widget-content">
                                        <ul class="list-style-two">
                                             <li><a href="<?php echo base_url("Home"); ?>">Home</a></li>
                                            <li><a href="<?php echo base_url("About"); ?>">About Us</a></li>

                                           

                                             <li><a href="<?php echo base_url("Product"); ?>">Product </a></li>
                                            <li><a href="<?=base_url("Contact"); ?>">Contact Us</a></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>

        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright-text">Design and Developed by <a href="https://comtranse.in" target="_blank"><b>Comtranse Technology Pvt.Ltd</b></a>, Kolhapur .</div>
            </div>
        </div>
    </footer>
    <!-- End Main Footer -->
</div>

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up" style="font-size: 25px"></span></div>


  
<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>

 
<!--This page JavaScript -->
    <script src="<?php echo base_url(); ?>web_resources/dist/js/sweetalert.min.js"></script>

  
<script  src="<?php echo base_url(); ?>web_resources/dist/js/common/common_validations.js"></script>

 
 <script src="<?=base_url("Assets/js/popper.min.js") ?>"></script>
<script src="<?=base_url("Assets/js/bootstrap.min.js") ?>"></script>

<script src="<?=base_url("Assets/js/wow.js") ?>"></script>
<script src="<?=base_url("Assets/js/appear.js") ?>"></script>
<script src="<?=base_url("Assets/js/script.js") ?>"></script>
<script src="<?=base_url("Assets/js/slick.js") ?>"></script>
<script src="<?=base_url("Assets/js/aos.js") ?>"></script>
<script src="<?=base_url("Assets/js/custom.js") ?>"></script>




<script type="text/javascript">
    
   var a=false;
$(document).ready(function(){
    
$("#enquery").click(function(){

  if(a==false){
    
    saveperformc();
   }
  }); 
});


 function saveperformc() 
{ 
    var personName=$('#person').val();
    var MobileNo=$('#mob').val();
    var message=$('#msg').val();
   
    var userId=$('#userId').val();


    if(personName==""|| MobileNo==""|| message=="") 
    {
        swal({
        title:"",
        text:"Please Enter Required Fields",
        type:"error",           
    });   
  }

    // else
    // {
    //   if(userId>0)
    //   {
     
    //   }
        else
      {
        a=true;
        
        $.ajax({
        url:base_path+"Home/insertEnquery",
        type: "POST",
        data: $('#Form').serialize(),
         beforeSend: function(){
               $('#enquery').prop('disabled', true);
               $('#enquery').html('Loading');
          }, 
        success: function(data) {

            $('#enquery').prop('disabled', false);
           $('#enquery').html('Save');
             $("#Form").trigger("reset");
          swal({
            title:"",
            text:"Data Submitted Successfully",
            type:"success",
            showCancelButton: false, 
            showConfirmButton: false,
             width: '1000px',
            timer:1000
        });

            window.location.href = base_path+"Home";
           $('#Form').parsley().destroy();
           $('#Form').parsley();
           a=false;

                }
      });
      }
      }
 // }

</script>

 

</body>


</html>