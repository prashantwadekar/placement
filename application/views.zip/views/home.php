    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    

  <!--  -->
    <!-- Banner Section start -->
    

    <section id="slick">
    <div class="">
        <div class="row">
            <div class="col-lg-12" style="line-height:11px;">
                <div class="slider_content d-none d-md-block">
                    
                    <div class="slider_items  ">
                        <img src="<?=base_url("Assets/images/main-slider/slider12.jpg") ?>"class="slick_img" >
                    </div>
                  
                     

                    <div class="slider_items ">
                        <img src="<?=base_url("Assets/images/main-slider/slider13.jpg") ?>"class="slick_img" >
                    </div>    
                </div>
                 


                 <div class="slider_content1 d-block d-md-none">
                    
                
                    <div class="slider_items ">
                        <img src="<?=base_url("Assets/images/main-slider/m_slider11.jpg") ?>"style="" class="slickm_img" >
                    </div>
                  
                     

                    <div class="slider_items ">
                         <img src="<?=base_url("Assets/images/main-slider/m_slider2.jpg") ?>"style="" class="slickm_img" >
                    </div>

                  

                   
                      
                     
                    
                </div>



                 <div class=" container after_banner d-none   d-lg-block">

                         <div class="col-10 mx-auto" style="position: absolute;
     left: 8%;
      bottom: -37px;">
                            <div class="col-12 card" >
                            <div class="row">
                                <div class="col-6 left"> 
                                <h4 ><!-- <img src="<?=base_url() ?>Assets/images/icons/vision.png" style="height: 35px;width: 35px;"> -->&nbsp;OUR VISION</h4>
                                <p>umiko  will produce high quality products and corrugation packing solutions to meet the expectations of the Indian.</p>
                                </div>

                                 <div class="col-6 right"> 
                                <h4><!-- <img src="<?=base_url() ?>Assets/images/icons/mission.png" style="height: 35px;width: 35px;"> -->&nbsp;OUR MISSION</h4>
                                <p>To provide sustainable product with enduring commitment by delivering superior products .</p>
                                </div>
                            </div>
                        </div></div>
                        
                    </div> 

                  

                <div class="arrow_prev">
                    <span><i class="fas fa-chevron-left fa-1x "></i></span>
                </div>
                <div class="arrow_next">
                    <span><i class="fas fa-chevron-right fa-1x "></i></span>
                </div>
            </div>
        </div>
    </div>
 </section>
    <!--END Banner Section -->


      <!-- About Us -->
   
    <!-- End About Us -->
    <!-- End About Us -->

    <!-- Services Section -->
    <section class="services-section ">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-title text-center">
                        <h2>Our Products</h2>
                       
                    </div>
                </div>
               
            </div>


                 <div class="container d-none d-sm-block d-md-block pb-2">
                    <div class="row">
                        <div class="col-12 col-md-4">
                    <div class="card-wrapper one" >
  <div class="card-header">
   <!--  <i class="fas fa-chess-rook"></i> -->
    <img src="<?=base_url() ?>Assets/img/products/dish_washN.png" style="height:165px;width: 40%;">
     <h1 class="card-header-text2">Dish Wash</h1>
    <p class="card-header-text3">Take Umiko Dish Wash gel 5 ml (1 Teaspoon) into bowl of water (50 ml) dip the scrubber squire it to get powerful cleaning solution to clean your utensils with sparkling shine.
</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>  
    


      <!--  Second Row -->
      <div class="col-12 col-md-4">
   <div class="card-wrapper two" >
  <div class="card-header">
   <img src="<?=base_url() ?>Assets/img/products/soft_soapN.png" style="height:165px;width: 40%;">
   
    <h1 class="card-header-text2">Soft Soap</h1>
    <p class="card-header-text3">Use soap & water,Rub hands,Dry with paper towel,Use towel to turn off faucet.
</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products/soft_soap") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>

<!--  Third Row -->
<div class="col-12 col-md-4">
     <div class="card-wrapper three" >
  <div class="card-header">
    <img src="<?=base_url() ?>Assets/img/products/toiletN.png" style="height:165px;width: 35%;">
    <h1 class="card-header-text2">TOILET CLEANER</h1>
    <p class="card-header-text3">Flush, Remove container cap & direct nozzle under toilet rim, squire liquid around the sides,  Leave it for 4 to 5 minutes, Brush it gently  Flush once more for sparkling & fresh toilets.</p>
  </div>
  <div class="card-footer">
    <div class="footer-content-wrap">
      <div class="footer-text-wrap">
        <h6 class="text-white  read_more"><a href="<?=base_url("Products/product4") ?>" class="text-white">Read More</a></h6>
       <!--  <p>step</p> -->
      </div>
      <i class="fas fa-angle-double-right"></i>
    </div>
  </div>
</div>
</div>

</div>

  
     



</div>


 </div>

            
           

    </section>
    <!-- End service Section -->

   

     <!-- Services Section Mobile View --> <!--  -->
    <section class="services-section d-block d-sm-none d-md-none d-lg-none homeproduct ">
  <div class="auto-container container">
           
          
          <div class="row">

                <div class="col-lg-4 col-md-6 col-6 mb-3 px-2">
                  
                 <div class="a-box">
                  
                    <a href="<?=base_url() ?>Products">
                  <div class="img-container text-center">
                    <div class="img-inner text-center">
                      <div class="inner-skew text-center">
                       <img src="<?=base_url("Assets/img/products/dish_washN.png") ?>"style="height: 145px;width: 63%;">
                      </div>
                    </div>
                  </div>

                  <div class="text-container ">
                    <h3 class="text-center">Dish Wash</h3>
                    <div>
                     <p class="text-center"> Take Umiko Dish Wash gel 5 ml (1 Teaspoon) into bowl of water (50 ml) dip the scrubber squire it to get powerful cleaning solution to clean your utensils with sparkling shine.</p>

                     <a href="<?=base_url() ?>Products" class="readmore text-left">Read more....</a>
                  </div>
            </div>   
            </div>
        </div></a>
         
         <div class="col-lg-4 col-md-6 col-6 mb-3 px-2">
                 <div class="a-box">
                  <a href="<?=base_url() ?>Products/product2">
                  <div class="img-container text-center">
                    <div class="img-inner text-center">
                      <div class="inner-skew">
                       <img src="<?=base_url("Assets/img/products/surfaceN.png") ?>"style="height: 145px;width: 65%;">
                      </div>
                    </div>
                  </div>
                  <div class="text-container">
                    <h3 class="text-center">Surface Floor Cleaner</h3>
                    <div>
                      <p class="text-center"> Take 1 cap full Umiko Surface floor cleaner and add in to half of bucket for regular use.Apply directly on oily and heavy stained surface leave it for 10
minute and rinse with water.</p>

                     <a href="<?=base_url() ?>Products/product2" class="text-left readmore" >Read more....</a>
                  </div>
            </div>   
            </div>
        </div>
        </div>
     
     <div class="row">
                <div class="col-lg-4 col-md-6 col-6 mb-3 px-2">
                 <div class="a-box">
                  <a href="<?=base_url() ?>Products/soft_soap">
                  <div class="img-container text-center">
                    <div class="img-inner text-center">
                      <div class="inner-skew">
                       <img src="<?=base_url("Assets/img/products/soft_soapN.png") ?>"style="height: 145px;width: 65%;">
                      </div>
                    </div>
                  </div>
                  <div class="text-container">
                    <h3 class="text-center">Soft Soap</h3>
                    <div>
                     <p class="text-center"> Use soap & water,Rub hands,Dry with paper towel,Use towel to turn off faucet.</p>
                  <a href="<?=base_url() ?>Products/soft_soap" class="text-left readmore" >Read more....</a>
                  </div>
            </div>   
            </div>
        </div>
         
         <div class="col-lg-4 col-md-6 col-6 mb-3 px-2">
                 <div class="a-box">
                  <a href="<?=base_url() ?>Products/product4">
                  <div class="img-container">
                    <div class="img-inner">
                      <div class="inner-skew">
                       <img src="<?=base_url("Assets/img/products/toiletN.png") ?>"style="height: 145px;width: 65%;">
                      </div>
                    </div>
                  </div>
                  <div class="text-container">
                    <h3>Toilate Cleaner</h3>
                    <div>
                      <p> Flush, Remove container cap & direct nozzle under toilet rim, squire liquid around the sides,  Leave it for 4 to 5 minutes, Brush it gently  Flush once more for sparkling & fresh toilets.</p>

                  
                  </div>
                   <a href="<?=base_url() ?>Products/product4" class="text-left readmore" >Read more....</a>  
            </div> 

            </div>
        </div>
        </div>

        
       

        
       
    </section>
    <!-- End  MOBILE serviceS Section -->


   <!-- Testimonial Section Two -->
    
    <!--End Testimonial Section -->



   

    <!-- Offer Section -->
    <section class="offer-section d-none d-md-block" style="background-image: url(images/background/15.jpg);">
        <div class="bg-pattern"></div>
        <div class="auto-container">
            <div class="sec-title text-center"data-aos="fade-right">
                <h2>Get in touch</h2>
               <!--  <div class="text">What We Provide For You check now and deside it<br> do you want now this</div> -->
            </div>
            <div class="row no-gutters">
                <div class="content-column col-xl-7 col-lg-6 col-md-12 col-sm-12 order-2">
                    <div class="inner-column">
                        <span class="title">PRODUCTS</span>
                       <li class="text"><span class="fa fa-pagelines fa-1x" style="color: #003300"></span>&nbsp;ALL PRODUCTS CONCENTRATE</li>
                        
                        <li class="text"><span class="fa fa-pagelines fa-1x" style="color: #003300"></span>&nbsp;DISH WASH</li>

                        <li class="text"><span class="fa fa-pagelines fa-1x" style="color: #003300"></span>&nbsp;FLOOR CLEANER</li>

                         <li class="text"><span class="fa fa-pagelines fa-1x" style="color: #003300"></span>&nbsp;SOFT SOAP</li>

                          <li class="text"><span class="fa fa-pagelines fa-1x" style="color: #003300"></span>&nbsp;TOILET CLEANER</li>


                        <div class="fact-counter">
                            <div class="row clearfix">
                                <!--Column-->
                                <div class="counter-column col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                                    <div class="inner-column">
                                        <span class="icon far fa-building"></span>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="2021">2021</span></div>
                                        <h4 class="counter-title">Established in the year 2021</h4>
                                    </div>
                                </div>

                                <!--Column-->
                                <div class="counter-column col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                                    <div class="inner-column">
                                        <span class="icon flaticon-door-1"></span>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="1">0</span></div>
                                        <h4 class="counter-title">Local Branches in <br>Karnataka</h4>
                                    </div>
                                </div>

                                <!--Column-->
                                <div class="counter-column col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                                    <div class="inner-column">
                                        <span class="icon flaticon-team"></span>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="8">0</span>k</div>
                                        <h4 class="counter-title">Happy Customer <br>with our work</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="form-column col-xl-5 col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="discount-form">
                            <div class="text">Fill out the form, Our manager will contact you for further details.</div>
                            <!--Comment Form-->
                            <!-- <form role="form" id="Form" action="" method="post"> -->
                          <form role="form" id="Form" action="" method="post">
                                <div class="form-group">
                                    <div class="response"></div>
                                </div>

                                <div class="form-group">
                                   <input type="text" id="userNm" name="userNm" class="username" placeholder="Name" *autofocus="autofocus" onkeypress="return onlyAlphabets(event,this)"  value="" data-parsley-trigger="change"  required>
                                    
                                    <!-- Update code -->
                                    <input type="hidden" class="form-control form-control-sm" id="userId" name="userId"  value="" data-parsley-trigger="change"  required>
                                </div>

                                <div class="form-group">
                                     <input type="text" id="MobNo" name="MobNo" class="username" placeholder="Mobile no" *autofocus="autofocus" onkeypress="return isNumberKey(event,this)"  value="" data-parsley-trigger="change" maxlength="10" maxlength="10" required>
                                </div>

                                <div class="form-group">
                                     <input type="email" name="emailh" id="emailh" class="email" placeholder="Email"*autofocus="autofocus" value="" data-parsley-trigger="change"  required>
                                </div>
                                
                                <div class="form-group">
                                    <textarea name="Requirments" id="Requirments" class="message" placeholder="Requirments"*autofocus="autofocus" value="" data-parsley-trigger="change"  required></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <button class="theme-btn btn-style-two" onclick="" type="button" name="save" id="save"><span class="btn-title">Submit Now</span> <span></span><span></span><span></span><span></span></button>
                                </div>
                            </form>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </section>
    <!--End Offer Section -->

  <script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>           
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Homecontact_create.js"></script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/common/common_validations.js"></script>

   