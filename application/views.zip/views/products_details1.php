
<style type="text/css">
 
#menu {margin-bottom: 7px;}


.tab-menu {padding-bottom: 0.25em;  }


.tab-menu .about{
  cursor: pointer;
    transform: perspective(1px) translateZ(0);
    -webkit-transition-duration: 0.3s;
    transition-duration: 0.3s;
}
.tab-menu .prod:hover{
  background: #ff5503!important;
  cursor: pointer;
    box-shadow: 0 10px 10px -10px rgb(0 0 0 / 50%)!important;
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
}
.tab-menu .prod1:hover{
  background: #ff5503!important;
  cursor: pointer;
    box-shadow: 0 10px 10px -10px rgb(0 0 0 / 50%)!important;
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
}

.tab-index.selected {
  text-shadow: 0px 1px 1px rgba(0,0,0,0.1);
  border-bottom: solid 2px green; 
  color: white; 
 
 
}

.tab-content:not(.selected) {display: none;}




</style>

 <!-- Services Section  d-none d-md-block -->
    <section class="services-section  products" style="padding: 10px 0 20px!important;">
        <div class="container-fluid ">
             <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-title text-center"data-aos="zoom-up">
                        <h2>Product Details</h2>
                       
                    </div>
                </div>
               
            </div>

       
</div>

          <div class="container productdetail mt-2">
            
              

              <div class="col-md-12 col-12">
                 <!-- <div class="card shadow-lg p-3"> -->
               <div class="row">

                 <div class="col-12 col-md-3 text-center">
                   <a href="#"><img src="<?=base_url() ?>Assets/img/products/dish_washN.png"  data-aos="zoom-in" ></a>
                 </div>

                 <div class="col-md-9 col-12 ">
                  <div class="d-flex justify-content-between mb-1">
                    <div>
                   <h4>Dish Wash</h4>
                 <h6 class="p-1 " style="color: #076c1f!important;font-size: 20px;"><i class="fas fa-rupee-sign" style="font-size: 17px;"></i>&nbsp;80</h6></div>

                <!--  <div class="d-none d-md-block"><button class="btn btn-default text-center text-white m-2 btn"><i class="fas fa-cart-arrow-down text-white" style="animation: blinker 1s linear infinite;"></i>&nbsp;Order Now</button></div> -->
               </div>




    <div id="menu" class="tab-menu">
  <div>
   <!--  <b>Javascript Tabbed Menu</b> -->
    <a href="#menu" data-click-switch="menu about selected" class="menu about tab-index selected prod mt-2"><!-- <i class="fas fa-info-circle"></i> -->Uses</a>

  

    <a href="#menu" data-click-switch="menu fruit-menu selected" class=" prod2 menu fruit-menu tab-index mt-2 "><!-- <i class="fas fa-info-circle" style="animation: blinker 1s linear infinite;"></i>&nbsp; -->Information</a>
   
  </div>
</div>


<div id="about" class="menu about tab-content selected">
 
  <li>Take Umiko Dish Wash gel 5 ml (1 Teaspoon) in to bowl of water (50 ml) dip the scrubber squire it to get powerful cleaning solution to clean your utensils with sparkling shine</li>
</div>



<div id="fruit" class="menu fruit-menu tab-content">
 
  <div class="fruit apple tab-content selected">
    <li>Keep away from reach of children.</li>
       <li>Avoid contact with eyes.</li>
       <li>Protect from direct sunlight. </li>
       <li>Keep in original container & don't remove labels until container is empty & rinse out.</li>
       <li>For external use only, not for medical use.</li>
       <li>Any contact with eyes rinse with plenty of water.</li>
  </div>

  
  
</div>




                <hr style="margin: 3px 6px!important">
                
                    <div class="top-right">
                   
               
                    <ul class=" social-icon-one clearfix ml-0 cardicon">

                        <li><a href="#"style="background: #3b5998;"><i class="fab fa-facebook-f"></i></a></li>

                        <li><a href="#"style="background: #1DA1F2;"><i class="fab fa-twitter" ></i></a></li>
                        <li><a href="#"style="background: #4285F4;"><i class="fab fa-google-plus-g" ></i></a></li>
                        
                        <li><a href="#"style="background: #0072b1;"><i class="fab fa-linkedin-in" ></i></a></li>
                        <!-- <li><a href="#"style="background: #FF0000;"><i class="fab fa-youtube" ></i></a></li>
                        <li><a href="#"style="background: #0072b1;"><i class="fab fa-linkedin-in" ></i></a></li> -->
                    </ul> </div> 
                 <div class="col-12 mt-1">
                   
                   <!-- <div class="text-center">
                     <div class="d-block d-md-none"><button class="btn btn-default text-center text-white m-2 btn"><i class="fas fa-cart-arrow-down text-white" style="animation: blinker 1s linear infinite;"></i>&nbsp;Order Now</button></div></div>
                 </div> -->
               </div>

              </div></div>


              </div>

             </div>

              
            


            </div>
          
</section>




<script type="text/javascript">
  // Helper Functions
util = {
  on: function(source, action, target, callback) {
    var fn;

    // target is given. Attach listener to source and look for target.   
    if (arguments.length > 3) {
      fn = function(e)  {
        // Ensure correct event parameter for older browsers.
        e = e ? e : window.event;

        // Create list of possible targets.
        var targets = source.querySelectorAll(target);

        // Only execute function if the event target matches the target query.
        for (var i = 0, len = targets.length; i < len; i++) if (e.target === targets[i]) return callback(e, source);

        return null;
      }
    }

    // no target is given.
    else fn = function(e) {return target(e, source)};    

    // attach events
    var actions = action.split(' ');
    for (var i = 0, len = actions.length; i < len; i++) {
      // Mozilla, Netscape, Firefox
      if (window.addEventListener) source.addEventListener(actions[i], fn, false);
      // IE
      else if (window.attachEvent) source.attachEvent('on' + actions[i], fn);
      // Fail Safe
      else source['on' + actions[i]] = fn;
    }
    return fn;    
  },
  
  separate: function(text, delimiter, spaces) {return text.trim().split(new RegExp('[' + ((delimiter || ',;\\s') + (delimiter && spaces ? '\\s' : '')) + ']+'))},
  
  hasClass: function(e, c) {return !!e.className.match(new RegExp('(\\s|^)' + c + '(\\s|$)'))},

  addClass: function(e, c) {if (!util.hasClass(e, c)) e.className += ' ' + c},

  removeClass: function(e, c) {
    if (util.hasClass(e, c)) {
      var reg = new RegExp('(\\s|^)' + c + '(\\s|$)');
      e.className = e.className.replace(reg, ' ');
    }
  }
}

function initSwitches() {
  
  // Event handler for clicking a switch.
  function clickHandler(evt) {
    var attr = util.separate(evt.target.getAttribute('data-click-switch')); // group, target, class
    if (attr.length > 2) {  
      // Turn off all in group.
      var group = document.getElementsByClassName(attr[0]);
      for (var i = 0, len = group.length; i < len; i++) util.removeClass(group[i], attr[2]);
      // Turn on all targets.
      var target = document.getElementsByClassName(attr[1]);
      for (var i = 0, len = target.length; i < len; i++) util.addClass(target[i], attr[2]);
      // Do not follow links.
      evt.preventDefault();
    }
  }
  
  // Event handler for hovering over a switch.
  function hoverHandler(evt) {
    var attr = util.separate(evt.target.getAttribute('data-hover-switch')); // target, class
    if (attr.length > 1) {
      var targets = document.getElementsByClassName(attr[0]);
      // Turn on all in group
      if (evt.type == 'mouseenter') for (var i = 0, len = targets.length; i < len; i++) util.addClass(targets[i], attr[1]);      
      // Turn off all in group
      if (evt.type == 'mouseleave') for (var i = 0, len = targets.length; i < len; i++) util.removeClass(targets[i], attr[1]);
    }
  }
  
  // Add an event to all switches.
  var switches;
  switches = document.querySelectorAll('[data-click-switch]');
  if (switches) for (var i = 0, len = switches.length; i < len; i++) util.on(switches[i], 'click', clickHandler);
  switches = document.querySelectorAll('[data-hover-switch]');
  if (switches) for (var i = 0, len = switches.length; i < len; i++) util.on(switches[i], 'mouseenter mouseleave', hoverHandler);
  
}

initSwitches();

// data-switch="click fruit apple selected; hover fruit-hover apple-hover selected"
</script>







 



   